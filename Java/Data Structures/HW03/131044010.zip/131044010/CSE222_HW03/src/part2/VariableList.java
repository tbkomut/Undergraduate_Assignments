package part2;

// These class is from course book
public class VariableList {

    private Node head = null;
    private int size = 0;

    private static class Node {
        private Variable data;
        private Node next;

        private Node(Variable variable) {
            data=variable;
            next = null;
        }

        private Node(Variable variable, Node nodeRef) {
            data=variable;
            next = nodeRef;
        }
    }

    public void addFirst(Variable variable) {
        head = new Node(variable,head);
        size++;
    }
    private void addAfter(Node node, Variable variable) {
        node.next = new Node(variable,node.next);
        size++;
    }

    private Variable removeAfter(Node node) {
        Node temp = node.next;
        if (temp != null) {
            node.next = temp.next;
            size--;
            return temp.data;
        } else {
            return null;
        }
    }

    private Variable removeFirst() {
        Node temp = head;
        if (head != null) {
            head = head.next;
        }
        if (temp != null) {
            size--;
            return temp.data;
        } else {
            return null;
        }
    }

    private Node getNode(int index) {
        Node node = head;
        for (int i = 0; i < index && node != null; i++) {
            node = node.next;
        }
        return node;
    }

    public Variable get(int index) {
        if (index < 0 || index >= size) {
            throw new IndexOutOfBoundsException(Integer.toString(index));
        }
        Node node = getNode(index);
        return node.data;
    }

    public double getValue(String name){
        Node temp=head;
        double val=0;
        while(temp!=null){
            if(temp.data.getterVar().equals(name)){
                val=temp.data.getterValue();
                break;
            }
            temp=temp.next;
        }
        return val;
    }

    public Variable set(int index, Variable newValue) {
        if (index < 0 || index >= size) {
            throw new IndexOutOfBoundsException(Integer.toString(index));
        }
        Node node = getNode(index);
        Variable result = node.data;
        node.data = newValue;
        return result;
    }

    public void add(int index, Variable item) {
        if (index < 0 || index > size) {
            throw new IndexOutOfBoundsException(Integer.toString(index));
        }
        if (index == 0) {
            addFirst(item);
        } else {
            Node node = getNode(index-1);
            addAfter(node, item);
        }
    }

    public boolean add(Variable item) {
        add(size, item);
        return true;
    }

    public int getterSize(){
        return size;
    }

}
