package part2;

public class Driver2 {
    public static void main(String args[]){
        try {
            // "infix_test_file_1.txt"
            Calculator item=new Calculator(args[0]);
            if(item.balancedBrackets()) {
                //System.out.println("Infix form of expression   => " + item.getterExpression());
                item.baseInfix();
                //System.out.println("Postfix form of expression => " + item.getterExpression());
                double result=item.evaluationPostfixForm();
                System.out.println("Expression result is       => " +result);
            }
            else
                System.out.println("Unbalanced expression.");
        }
        catch (Exception e) {
            System.out.println("-->" + e.getMessage());
        }
    }
}