package part2;

public class Variable {
    private String variableName=null;
    private double value=0;

    public Variable(){

    }

    public Variable(String variable,double val){
        variableName=variable;
        value=val;
    }

    public String getterVar(){
        return variableName;
    }

    public double getterValue(){
        return value;
    }


    public void setterVar(String var){
        variableName=var;
    }

    public void setterValue(double val){
        value=val;
    }

    @Override
    public String toString() {
        return variableName + " " + value;
    }
}
