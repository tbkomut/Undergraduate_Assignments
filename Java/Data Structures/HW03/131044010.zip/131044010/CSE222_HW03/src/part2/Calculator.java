package part2;
import part1.ImageStack;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.NoSuchElementException;

public class Calculator {

    private VariableList variables=null;
    private String expression=null;
    private static final String highPriority="*/";
    private static final String lowPriority="+-";

    public Calculator(String filename) throws Exception {
        variables=new VariableList();
        if(!fileInputChecking(filename))
            throw new Exception("File exits exception");
    }

    public String getterExpression(){
        return expression;
    }

    public double evaluationPostfixForm(){
        double result=0;
        Variable temp=null;
        ImageStack<String> evaluation=new ImageStack<>();
        String[] parts = expression.split("\\s+");
        double val1=0,val2=0;
        for(int i=0;i<parts.length;++i) {
            if (highPriority.contains(parts[i]) || lowPriority.contains(parts[i])) {
                String str1 = evaluation.pop();
                String str2 = evaluation.pop();
                try {
                    val1 = Double.valueOf(str1);
                } catch (Exception e) {
                    val1 = variables.getValue(str1);
                }
                try {
                    val2 = Double.valueOf(str2);
                } catch (Exception e) {
                    val2 = variables.getValue(str2);
                }
                if (parts[i].equals("+"))
                    result = val2 + val1;
                if (parts[i].equals("-"))
                    result = val2 - val1;
                if (parts[i].equals("*"))
                    result = val2 * val1;
                if (parts[i].equals("/"))
                    result = val2 / val1;
                evaluation.push(String.valueOf(result));
            }
            else if(parts[i].equals("abs")){
                String str1 = evaluation.pop();
                try {
                    val1 = Double.valueOf(str1);
                } catch (Exception e) {
                    val1 = variables.getValue(str1);
                }
                if(val1*1000<0){
                    val1*=-1;
                }
                evaluation.push(String.valueOf(val1));
            }
            else if(parts[i].equals("cos")){
                String str1 = evaluation.pop();
                try {
                    val1 = Double.valueOf(str1);
                } catch (Exception e) {
                    val1 = variables.getValue(str1);
                }
                evaluation.push(String.valueOf(radianCalculator("cos",val1)));
            }
            else if(parts[i].equals("sin")){
                String str1 = evaluation.pop();
                try {
                    val1 = Double.valueOf(str1);
                } catch (Exception e) {
                    val1 = variables.getValue(str1);
                }
                evaluation.push(String.valueOf(radianCalculator("sin",val1)));
            }
            else
                evaluation.push(parts[i]);
        }
        result=0;
        while(!evaluation.isEmpty())
            result+=Double.valueOf(evaluation.pop());
        return result;
    }

    private double radianCalculator(String type,double angle){
        double result=0;
        double radian;
        double power,j;
        double factor,k;
        if(type.equals("sin")) {
            boolean sign=true;
            // If angle less than zero then sign set to false and angle is multiple with -1.
            if(angle<0) {
                sign = false;
                angle*=-1;
            }
            if(angle%360>180) {
                angle = angle % 180;
                if(sign)
                    sign=false;
                else
                    sign=true;
            }
            else
                angle = angle % 180;
            radian=(angle/180)*3.14;
            for (int i = 1; i <= 11; i += 2) {
                for (j = 0, power = 1; j < i; j++)
                    power = power * radian;
                for(k=1,factor=1;k<=i;++k)
                    factor*=k;
                if ((i-1)%4 == 0) {
                    result += power / factor;
                } else {
                    result -= power / factor;
                }
            }

            if(!sign) {
                /*  This following line so interesting...  */
                if(result!=0)
                    result *= -1;
            }
        }
        else if(type.equals("cos")) {
            result=1.000;
            boolean sign=true;
            // If angle less than zero then sign set to false and angle is multiple with -1.
            if(angle<0)
                angle*=-1;
            if((angle%360>=90 && angle%360<180) || (angle%360>=180 && angle%360<270)) {
                sign = false;
                if(( angle%360>=90 && angle%360<180))
                    angle = (180-(angle % 180));
                else
                    angle = (angle % 180);
            }
            else if((angle%360>=0 && angle%360<90) || (angle%360>270 && angle%360<360)) {
                if(( angle%360>=270 && angle%360<360))
                    angle = (90-(angle % 90));
                else
                    angle = (angle % 90);
            }
            radian=(angle/180)*3.14;
            for(int i=2;i<=8;i+=2){
                for (j = 0, power = 1; j <i; j++)
                    power = power * radian;
                for(k=1,factor=1;k<=i;++k)
                    factor*=k;
                if (i%4!=0)
                    result -= (power/factor);
                else
                    result += (power/factor);
            }

            if(!sign) {
                if(result!=0)
                    result *= -1;
            }
            if((angle%90==0 && angle%180!=0)){
                if((angle%360)%90==0 && (angle%360)%270!=0)
                    result=1;
                else if(((angle%360)%90==0 && ((angle%360)%270==0)))
                    result=-1;
            }

        }
        return result;
    }


    public void baseInfix(){
        // assign to expression
        expression=infixToPostfix(expression);
    }

    public boolean balancedBrackets(){
        ImageStack<Character> brackets=new ImageStack<>();
        boolean result=true;
        try {
            for (int i = 0; i < expression.length() && result==true; ++i) {
                if (expression.charAt(i) == '(') {
                    brackets.push(expression.charAt(i));
                }
                else if (expression.charAt(i) == ')') {
                    char element = brackets.peek();
                    if(element=='(')
                        brackets.pop();
                    else
                        result=false;
                }
            }
            if(!brackets.isEmpty())
                result=false;
        }
        catch(NoSuchElementException e){
            result=false;
        }
        return result;
    }

    private String infixToPostfix(String exp){
        StringBuilder postFixForm=new StringBuilder();
        ImageStack<String> postFixOperation=new ImageStack<>();
        String[] parts = exp.split("\\s+");
        try {
            for (int i = 0; i < parts.length; ++i) {
                if (parts[i].equals("(")) {
                    postFixOperation.push(parts[i]);
                }
                else if (parts[i].equals(")")) {
                    String element;
                    while (!(element = postFixOperation.pop()).equals("(")) {
                        postFixForm.append(element);
                        postFixForm.append(" ");
                    }
                }
                else if (highPriority.contains(parts[i]) || lowPriority.contains(parts[i])) {
                    if(!postFixOperation.isEmpty()) {
                        String last = postFixOperation.peek();
                        if (lowPriority.contains(last) && highPriority.contains(parts[i]))
                            postFixOperation.push(parts[i]);
                        else if (lowPriority.contains(last) && lowPriority.contains(parts[i]))
                            postFixOperation.push(parts[i]);
                        else if (highPriority.contains(last) && highPriority.contains(parts[i]))
                            postFixOperation.push(parts[i]);
                        else if (lowPriority.contains(parts[i]) && highPriority.contains(last)) {
                            String element = postFixOperation.pop();
                            postFixForm.append(element);
                            postFixForm.append(" ");
                            postFixOperation.push(parts[i]);
                        }
                        else
                            postFixOperation.push(parts[i]);
                    }
                    else
                        postFixOperation.push(parts[i]);
                }
                else if(parts[i].equals("sin(") || parts[i].equals("cos(") || parts[i].equals("abs(")){
                    StringBuilder parameter=new StringBuilder();
                    int temp=i;
                    i++;
                    int j=0;
                    int count=1;
                //  Actually total complexity O(n) because i only is continued in following loop. There are no starting from zero or another value.
                    for(;j<count;i++){
                        if(parts[i].equals("sin(") || parts[i].equals("cos(") || parts[i].equals("abs("))
                            count++;
                        if(parts[i].equals(")"))
                            j++;
                        parameter.append(parts[i]);
                        parameter.append(" ");
                    }
                    String item=infixToPostfix(parameter.toString());
                    postFixForm.append(item);
                    postFixForm.append(parts[temp],0,3);
                    postFixForm.append(" ");
                    i--;
                }
                else {
                    postFixForm.append(parts[i]);
                    postFixForm.append(" ");
                }
            }
            while(!postFixOperation.isEmpty()) {
                String item=postFixOperation.pop();
                if(!(item.equals("(") || item.equals(")"))) {
                    postFixForm.append(item);
                    postFixForm.append(" ");
                }
            }
        }
        catch(Exception e){
//            System.out.println(e.toString());
        }
        return postFixForm.toString();
    }

    private boolean fileInputChecking(String filename){
        boolean result=true;
        try {
            FileReader file=new FileReader(filename);
            BufferedReader buff = new BufferedReader(file);
            String input;
            boolean flag=false;
            // Dosya formatının nasıl olacağını kesinlikle rapora belirt.
            while((input=buff.readLine())!=null) {
                if (input.length() == 0)
                    flag = true;
                else {
                    int i = 0;
                    if (flag == false) {
                        if (input.contains("=")) {
                            StringBuilder value = new StringBuilder();
                            while (input.charAt(i) != '=')
                                value.append(input.charAt(i++));
                            String name = value.toString();
                            value = new StringBuilder();
                            i++;
                            while (i < input.length())
                                value.append(input.charAt(i++));
                            double val = Double.parseDouble(value.toString());
                            variables.add(new Variable(name, val));
                        }
                    }
                    else
                        expression = input;
                }
            }
        }
        catch (IOException e){
            result=false;
        }
        return result;
    }

}