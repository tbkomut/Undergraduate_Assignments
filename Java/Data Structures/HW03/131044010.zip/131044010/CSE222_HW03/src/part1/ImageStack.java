package part1;

import java.util.NoSuchElementException;

// Stack is implemented with linkedList. These code from course book
public class ImageStack<E> {

    private static class Node<E>{
        private E data;
        private Node next;

        private Node(E dataItem) {
            data = dataItem;
            next = null;
        }
        private Node(E dataItem, Node nodeRef) {
            data = dataItem;
            next = nodeRef;
        }

        public String toString(){
            return data.toString();
        }
    }

    private Node<E> topOfStackRef = null;

    public E push(E obj) {
        topOfStackRef = new Node(obj, topOfStackRef);
        return obj;
    }

    public E pop() {
        if (isEmpty()) {
            throw new NoSuchElementException();
        }
        else {
            E result = topOfStackRef.data;
            topOfStackRef = topOfStackRef.next;
            return result;
        }
    }

    public E peek() {
        if (isEmpty()) {
            throw new NoSuchElementException ();
        }
        else {
            return topOfStackRef.data;
        }
    }

    public boolean isEmpty() {
        return topOfStackRef == null;
    }

    public String toString(){
        return topOfStackRef.toString();
    }

}
