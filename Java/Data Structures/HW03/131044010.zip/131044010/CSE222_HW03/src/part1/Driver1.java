package part1;

public class Driver1 {
    public static void main(String args[]){
        // "test_file_1.txt"
        try {
            System.out.println(args[0]);
            ImageDigital item=new ImageDigital(args[0]);
            System.out.println("Number of components = "+ item.componentsOfImage());
        }
        catch (Exception e) {
           System.out.println(e.getMessage());
        }
    }
}




