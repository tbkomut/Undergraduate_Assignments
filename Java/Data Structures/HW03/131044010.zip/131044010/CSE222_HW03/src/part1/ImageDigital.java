package part1;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.NoSuchElementException;

public class ImageDigital {

    private ImageStack<String> myStack;
    private int numberOfComponents;

    public ImageDigital(String filename) throws Exception {
        myStack=new ImageStack();
        numberOfComponents=0;
        if(!fileInputChecking(filename))
            throw new Exception("File exits exception");
    }

    public int componentsOfImage() throws Exception {
        String pre=null,post,exc;
        try {
            while (!myStack.isEmpty()) {        /* O(row)* O(column) = O(n) */
                pre=myStack.pop();
                post=myStack.peek();
                componentAnalyze(pre, post);
            }
        }
        catch(NoSuchElementException e){
            numberOfComponents+=lastLineAnalyze(pre);   /*  O(column)   */
        }
        return numberOfComponents;
    }

    /**
     * It finds number of components between two element ("pop" and "peek after pop").
     * @param previous  stack pop() element also current stack peek...
     * @param current   stack pop() then we take a peek element...
     * @return  number of components between two element ("pop" and "peek after pop").
     */
    private void componentAnalyze(String previous,String current){
        char prev,curr;
        /* Lock variable is checking for the state "1 to 0". */
        boolean lock=false;
        int[] status={0,0}; // status[0] is for previous-line  status[1] is for current-line...
        for(int i=0;i<previous.length();++i){
            prev=previous.charAt(i);
            curr=current.charAt(i);
            if(prev==curr && curr=='1'){
                /* because of merging so numberOfComponents-- */
                if(lock==true) {
                    numberOfComponents--;
                    lock=false;
                }
                status[0] = 1;
                status[1] = 1;
            }
            else if(prev!=curr && curr=='1'){
                if(lock==true)
                    lock=false;
                status[0]=0;
                status[1]=1;
            }
            else if(prev!=curr && curr=='0'){
                if(status[0]!=1) {
                    lock=true;
                    numberOfComponents++;
                }
                status[0]=1;
                status[1]=0;
            }
            else if(prev==curr && curr=='0'){
                if(lock==true)
                    lock=false;
                status[0]=0;
                status[1]=0;
            }
        }
    }

    private int lastLineAnalyze(String last) throws Exception {
        int result = 0;
        if(last==null)
            throw new Exception("Throwing Exception");
        else {
            int flag = 0;
            for (int i = 0; i < last.length(); ++i) {
                if (last.charAt(i) == '1') {
                    if (flag == 0)
                        result++;
                    flag = 1;
                } else if (last.charAt(i) == '0')
                    flag = 0;
            }
        }
        return result;
    }

    private boolean fileInputChecking(String filename){
        boolean result=true;
        try {
            FileReader file=new FileReader(filename);
            BufferedReader buff = new BufferedReader(file);
            String input;
            while((input=buff.readLine())!=null)
                myStack.push(input);
        }
        catch (IOException e){
            result=false;
        }
        catch(NullPointerException e){
            result=true;
        }
        return result;
    }

    /**
     * Last element will be in top of the Image Stack...
     * @return
     */
    public String toString(){
        StringBuilder result=new StringBuilder();
        try {
            while (!myStack.isEmpty()) {
                result.append(myStack.pop() + " ");
                result.append("\n");
            }
        }
        catch(NullPointerException e){
            result.append("\n");
        }
        return result.toString();
    }

}