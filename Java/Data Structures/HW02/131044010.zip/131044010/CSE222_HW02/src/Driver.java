public class Driver {
    public static void main(String args[]){
        try {
            ExperimentList items=new ExperimentList();
            // add method processes...
            items.addExp(new Experiment("Work4","05:32:07",true,1,2));
            items.addExp(new Experiment("Work2","09:52:17",false,4,0));
            items.addExp(new Experiment("Work3","13:32:26",true,1,4));
            items.addExp(new Experiment("Work1","03:45:59",true,4,3));
            items.addExp(new Experiment("Work3","01:39:55",true,4,2));
            items.addExp(new Experiment("Work2","01:01:11",false,5,0));
            items.addExp(new Experiment("Work1","19:32:51",true,2,4));
            items.addExp(new Experiment("Work2","20:32:16",true,3,2));
            items.addExp(new Experiment("Work1","07:15:22",true,1,4));
            items.addExp(new Experiment("Work3","23:55:00",true,1,2));
            items.addExp(new Experiment("Work1","21:37:03",true,5,4));
            items.addExp(new Experiment("Work3","20:48:44",true,5,3));
            items.addExp(new Experiment("Work1","21:38:04",true,3,1));
            System.out.println(items);

            /*

            //getExp method processes...
            System.out.println(items.getExp(5,2).getterSetUp());
*/

/*
            // to test setExp method processes...
            // If different days will be set. The method throws Exception. Since the day list may be damage
            // So  experiment's day's value that is set, is so important...
            System.out.println(items.setExp(3,0,new Experiment("Work3","11",true,3,1)).getterSetUp());
            System.out.println(items);
*/


/*
            // to test removeExp method...
            System.out.println(items.removeExp(5,2));
            System.out.println(items);
*/

/*
            // to test removeDay method...
            items.removeDay(3);
            items.removeDay(2);
            System.out.println(items);
*/

/*
            // to test listExp which returns a day list that contains completed experiment...
            System.out.println(items.listExp(4));
*/

/*
            // sorting from small to large
            // to test orderDay method...
            System.out.println("IN "+items);
            items.orderDay(1);
            System.out.println("OUT "+items);
*/

/*
            // sorting from small to large
            // to test orderExperiments method...
            System.out.println("INPUT LIST=     "+items);
            // You said that Following method returns a head Node, isn't list  in moodle web page
            ExperimentList instance=items.orderExperiments();
            System.out.println("UNCHANGED NORMAL OUTPUT LIST=    "+items);
            // I added Experiments that it's "completed=false" to list
            System.out.println("RETURNED CHANGED LIST.NODE=  "+instance);
*/

/*
            // to test iterator...
            Iterator iter=items.iterator();
            while(iter.hasNext())
                System.out.print(iter.next() + "  ");
            System.out.println("");

            // to test iterator that has one parameter...
            iter=items.iterator(4);
            while(iter.hasNext())
                System.out.print(iter.next() + "  ");
            System.out.println("");
*/

/*
            // Notice that iterator(10) that means actually iterator middle of 9-10. It doesn't mean index=10...
            Iterator iter=items.iterator(0);
            // It is get forward with iter.next() thus remove index=10 from list...
            System.out.println(iter.next());
            iter.remove();
            System.out.println(items);
*/

/*
            // When I make testing
            // I used Java toString methods to other targets which non-complex printing in Experiment Class.
            // So Additionally,I created a myToString method for all data fields.
*/


        }
        catch (Exception e) {
            System.out.println("Handle Exception: " + e.getMessage());
        }
    }
}
