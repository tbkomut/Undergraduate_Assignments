public interface Iterator {
    public boolean hasNext();
    public Experiment next() throws Exception;
    public void remove() throws Exception;
}
