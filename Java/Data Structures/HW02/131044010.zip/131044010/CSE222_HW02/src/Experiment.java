import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Experiment {
    private String setup=null;
    private int day=0;
    private String time=null;
    private boolean completed=false;
    private float accuracy=0;

    // Actually,It doesn't need a one parameter constructor except creating arrays.
    public Experiment(){

    }

    public Experiment(String setup, String time, boolean completed,int day, float accuracy) throws Exception {
        this.setup = setup;
        /*Maybe I could test for day value that can't be negative number. But I will check it in ExperimentList class, No problem  */
        this.day = day;;
        this.completed = completed;
        DateFormat dateFormat = new SimpleDateFormat(time);
        Date date = new Date();
        this.time=dateFormat.format(date);
        if(completed==false && accuracy!=0){
            throw new Exception("Completed false but accuracy is non-zero number!,Logical error!");
        }
        if(accuracy<0){
            throw new Exception("Accuracy can't be negative number.");
        }
        this.accuracy = accuracy;
    }

    // Getter functions for data information...

    public String getterSetUp(){
        return setup;
    }

    public int getterDay(){
        return day;
    }

    public String getterTime(){
        return time;
    }

    public boolean getterCompleted(){
        return completed;
    }

    public float getterAccuracy(){
        return accuracy;
    }

    // Setter functions for data information...

    public void setterSetUp(String setup){
        this.setup=setup;
    }

    public void setterDay(int day){ this.day=day; }

    public void setterTime(String time){
        this.time=time;
    }

    public void setterCompleted(boolean completed){
        this.completed=completed;
    }

    public void setterAccuracy(float accuracy){
        this.accuracy=accuracy;
    }

    public String toString() {
        return "Experiment{" +
                "setup='" + setup + '\'' +
                ", day=" + day +
                ", time='" + time + '\'' +
                ", accuracy=" + accuracy +
                ", completed=" + completed +
                '}';
    }

    public String myToString(){
        return getterSetUp()+ " " + getterDay()+ " " + getterTime()+ " " + getterCompleted()+ " " + getterAccuracy() ;
    }

}

