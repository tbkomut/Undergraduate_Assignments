import java.util.NoSuchElementException;

public class ExperimentList implements Iterable {

    private Node head=null;
    private int size=0;
    private int daySize=0;

    /**
     * Static inner class in ExperimentList. This class is useful for storing experiments data.
     */
    public static class Node{
        /**
         * It is an experiment object in Experiment List.
         */
        private Experiment data;
        /**
         * It is a next experiment object of an experiment object in Experiment list
         */
        private Node next=null;
        /**
         * It is a first experiment object of next day of an experiment in list.
         */
        private Node nextDay=null;

        public Node (Node item){
            data=item.data;
            next=item.next;
            nextDay=item.nextDay;
        }

        public Node(Experiment item){
            data=item;
        }

        public Node(Experiment item, Node nextItem){
            this(item);
            next=nextItem;
        }

        public Node(Experiment item, Node nextItem,Node nextDayItem){
            this(item,nextItem);
            nextDay=nextDayItem;
        }

        public String toString(){
            return data.toString();
        }
    }

    /**
     * This class provide with a iterator for ExperimentList class.
     */
    public class ExperimentIterator implements Iterator{

        /**
         * A reference to next item...
         */
        private Node nextItem;
        /**
         * A reference to the last the last item returned.
         */
        private Node lastItem;
        /**
         * The index of the current item.
         */
        private int index=0;

        public ExperimentIterator(){
            lastItem=null;
            nextItem=head;
        }

        public ExperimentIterator(int i){
            if(i<0 ||i>size){
                throw new IndexOutOfBoundsException("Invalid index");
            }
            lastItem=null;
            if(i==size){
                index=size;
                nextItem=null;
            }
            else{
                nextItem=head;
                for(index=0;index<i;index++){
                    lastItem=nextItem;
                    nextItem=nextItem.next;
                }
            }
        }

        /**
         * Indicate whether movement forward is defined.
         * @return true if call to next will not throw a exception
         */
        public boolean hasNext(){
            return nextItem!=null;
        }

        /**
         * Move the iterator forward and return the next item.
         * @return  The next item in the list.
         * @throws Exception NoSuchElementException if there is no such element.
         */
        public Experiment next() throws Exception{
            if(!hasNext()){
                throw new NoSuchElementException();
            }
            lastItem=nextItem;
            nextItem=nextItem.next;
            index++;
            return lastItem.data;
        }

        /**
         * Removing a item with iterator.
         * @throws Exception subprogram exceptions.
         */
        public void remove() throws Exception {
            int day=lastItem.data.getterDay();
            Node item=getDayNode(day);
            Node cond=item.nextDay;
            int i=0;
            while(item!=cond && item!=lastItem){
                i++;
                item=item.next;
            }
            removeExp(day,i);
        }
    }

    public ExperimentList(){

    }

    public ExperimentList(Node item) throws Exception {
        Node index=item;
        while(index!=null){
            addExp(index.data);
            index=index.next;
        }

    }

    // Getters methods necessary for unit testing... Don't necessary for setters
    public Node getterHead(){
        return head;
    }

    public int getterDaySize(){
        return daySize;
    }

    public int getterSize(){
        return size;
    }

    /**
     * Sorts all the experiments in the list according to the accuracy, the original list should not be changed since the day list may be damage
     * @return ExperimentList object is changed.
     * @throws Exception throws a subprograms exception
     */
    public ExperimentList orderExperiments() throws Exception {
        ExperimentList list=new ExperimentList(head);
        Node outer=list.head;
        Node inner=null;
        Node minExperiment=null;
        while(outer!=null){
            minExperiment=outer;
            inner=outer;
            while(inner!=null){
                if((inner.data.getterAccuracy()*1000)<(minExperiment.data.getterAccuracy()*1000))
                    minExperiment=inner;
                inner=inner.next;
            }
            Experiment temp=outer.data;
            outer.data=minExperiment.data;
            minExperiment.data=temp;
            outer=outer.next;
        }
        return list;
    }

    /**
     * Sorts the experiments in a given day according to the accuracy, the changes will be done on the list
     * @param day Parameter is that A day will be sorted...
     * @throws Exception throws a subprograms exception
     */
    public void orderDay(int day) throws Exception {
        Node access=getDayNode(day);
        Node next=null;
        Node cond=access.nextDay;;
        Node minExperiment;
        while(access!=cond){
            minExperiment=access;
            next=access.next;
            while(next!=cond) {
                if((next.data.getterAccuracy()*1000)<(minExperiment.data.getterAccuracy()*1000)) {
                    minExperiment = next;
                }
                next=next.next;
            }
            Experiment temp=minExperiment.data;
            minExperiment.data=access.data;
            access.data=temp;
            access=access.next;
        }
    }

    /**
     * List all completed experiments in a given day
     * @param day Parameter is that A day is it's list is returned...
     * @return only a specific day list, not all list
     * @throws Exception throws a subprograms exception(private methods)
     */
    public ExperimentList listExp(int day) throws Exception {
        ExperimentList list=new ExperimentList();
        Node temp=getDayNode(day);
        Node after=temp.nextDay;
        while(temp!=after) {
            if(temp.data.getterCompleted()==true) {
                list.addExp(temp.data);
                System.out.println(temp.data);
            }
            temp = temp.next;
        }
/*        if(temp.data.getterCompleted()==true)
            list.addExp(temp.data);
        temp = temp.next;
*/        return list;
    }

    /**
     * Remove all experiments in a given day
     * @param day Parameter is a day which will be removed related day list.
     * @throws Exception throws a subprograms exception(private methods)
     */
    public void removeDay(int day) throws Exception {
        Node temp=getDayNode(day);
        Node previous=previousList(temp);
        if(temp==head){
            if(head!=null)
                head=head.nextDay;
        }
        else {
            if (hasElement(previous)) {
                previous.nextDay=temp.nextDay;
                Node last=previous;
                // access to last element in specific dayList.
                while(hasElement(last))
                    last=last.next;
                last.next=temp.nextDay;
            }
            else {
                previous.nextDay = temp.nextDay;
                previous.next = temp.nextDay;
            }
        }
        daySize--;
    }

    /**
     * remove the experiment specified as index from given day
     * @param day   Removing a experiment from a specific day in list
     * @param index Removing indexth experiment in a specific day in list
     * @return  the removed element from list.
     * @throws Exception Index will be index>= 0 and index< size.
     */
    public Experiment removeExp(int day, int index) throws Exception {
        if(index<0 || index>=size){
            throw new Exception("Index bound error!");
        }
        Node element=getDayNode(day);
        Node temp=getDayIndex(element,index);
        // System.out.println(temp.data);
        Experiment result;
        if(temp==head)
            result=removeFirst();
        else {
            removeAfter(element, index);
            result=temp.data;
        }
        return result;
    }

    /**
     * set the experiment with the given day and position.
     * @param day   set an experiment from specific day in list
     * @param index set an indexth experiment  in specific day in list.
     * @param item  set an experiment element in list with parameter experiment item.
     * @return  return value is old experiment.
     * @throws Exception    Index will be index>= 0 and index< size.
     */
    public Experiment setExp(int day,int index,Experiment item ) throws Exception {
        if(index<0 || index>size){
            throw new Exception("Index bound error!");
        }
        /* the following if condition is important because */
        if(day!=item.getterDay()){
            throw new Exception("Experiment object's 'day' data field isn't equal to value in day parameter.");
        }
        Node element=getDayNode(day);
        element=getDayIndex(element,index);
        Experiment result= element.data;
        element.data= item;
        return result;
    }

    /**
     * Get the experiment with the given day and position
     * @param day   It should be day number is in list
     * @param index It is index'th element in experiments of a day.
     * @return  Index'th experiment in a day
     * @throws Exception    Index will be index>= 0 and index< size and day >= 0.
     */
    public Experiment getExp(int day,int index) throws Exception {
        if(index<0 || index>=size){
            throw new IndexOutOfBoundsException("My exception handle is=>" + Integer.toString(index));
        }
        if(day<0){
            throw new IndexOutOfBoundsException("Day value can't be less than 0.");
        }
        Node element=getDayNode(day);
        element=getDayIndex(element,index);
        return element.data;
    }

    /**
     * Insert experiment to the end of the day.
     * @param item Item is used to add in a last node.
     * @throws Exception Day will be day >= 0.
     */
    public void addExp(Experiment item) throws Exception {
        /*
            Important note, When I add experiments which have a new day to list,
            I have added the experiment which has a new day to the end of the list.
            Because I took the order of adding in the list as a criterion.
            I have got this information late.
            Already I think this information is not very clear in the pdf file.
        */
        int index=item.getterDay();
        if(index<0){
            throw new IndexOutOfBoundsException("Day number can't be negative or zero number!");
        }
        /*  Also Size ==0, there are no nodes in the list... */
        if(head==null){
            head=new Node(item,head,head);
            size++;
            daySize++;
            // System.out.println(head.data.getterDay());
        }
        else{
            /* The old variable for comparing old day number with new day number... */
            int old=daySize;
            /*
                addDayNode method is used to take forward in day list.
                daySize may be change in here.
            */
            Node node=addDayNode(index);
            /*
                It access the a specific day list with geyDayNode method.
                Now It will access last node in the day list with getDayLastNode (storing in temp variable)
            */
            Node temp=getDayLastNode(node);
            /*
                If "old daySize == new daySize",
                Only Last node is added in the specific day list and total node size updated.
            */
            if(old==daySize) {
                node = temp;
                node.next = new Node(item, node.next, node.nextDay);
                size++;
            }
            /*
                If "old daySize != new daySize",
                New item is added in "node.nextDay" then taking forward to last element in the specific day list
                After "last element.next==node.nextDay" and total node size updated.
            */
            else{
                Node instance=new Node(item,null,null);
                Node local=head;
                while(local!=null){
                    if(local.data.getterDay()>instance.data.getterDay())
                        break;
                    local=local.next;
                }
                if(local==head){
                    head=instance;
                    instance.next=local;
                    instance.nextDay=local;
                }
                else if(local==null){
                    node.nextDay=new Node(item,node.nextDay,node.nextDay);
                    Node last=node.nextDay;
                    node = temp;
                    node.next=last;
                }
                else{
                    Node prev=previousList(local);
                    Node record=prev.nextDay;
                    instance.nextDay=record;
                    instance.next=record;
                    Node cond=getDayLastNode(prev);;
                    prev.nextDay=instance;
                    if(prev.next==null)
                        prev.next=instance;
                    cond.next=instance;
                }
                size++;
            }
            // System.out.println(node.next.data.getterDay());
        }
    }

    /**
     * The method provide with iterator for ExperimentList class.
     * @return  ExperimentIterator (inner class) object initialising index=0.
     */
    public Iterator iterator(){
        return new ExperimentIterator();
    }

    /**
     * The method provide with iterator for ExperimentList class.
     * @param i It is a starting index for ExperimentList
     * @return  ExperimentIterator (inner class) object initialising index=i.
     */
    public Iterator iterator(int i){
        return new ExperimentIterator(i);
    }

    public String toString(){
        Node nodeRef=head;
        StringBuilder result=new StringBuilder();
        while(nodeRef!=null){
            result.append(nodeRef.data.getterSetUp() + "(");
            result.append(nodeRef.data.getterDay() + ")  ");
            nodeRef=nodeRef.next;
        }
        return result.toString();
    }


    private void removeAfter(Node item,int index)throws Exception{
        if (index == 0) {
            Node previous=previousList(item);
            if(hasElement(item))
                previous.nextDay=item.next;
            else
                previous.nextDay=item.nextDay;
            Node temp=previous;
            // access to last element in specific dayList.
            while(hasElement(temp))
                temp=temp.next;
            if(hasElement(item)) {
                temp.next = item.next;
                size--;
            }
            else {
                temp.next = item.nextDay;
                size--;
                daySize--;
            }
        }
        else{
            Node temp=getDayNode(item.data.getterDay());
            temp=getDayIndex(item,index-1);
            item=getDayIndex(item,index);
            temp.next=item.next;
            temp.nextDay=item.nextDay;
            size--;
        }
    }

    private Experiment removeFirst() throws Exception {
        Node temp=head;
        if(head!=null)
            head=head.next;
        if(temp!=null){
            size--;
            if(hasElement(temp)==true)
                temp.next.nextDay=temp.nextDay;
            return temp.data;
        }
        else
            return null;
    }

    // day tek elemanlı ise false döner.aksi halde true döner.
    private boolean hasElement(Node item) throws Exception {
        if(item==null)
            throw new Exception("Null node error handling!");
        if(item.data.getterDay()==item.next.data.getterDay())
            return true;
        return false;
    }

    // Node'un day listesinden bir önceki day list'in ilk node'unu döndürür.
    private Node previousList(Node item){
        Node nodeX=head;
        while (nodeX.nextDay != null) {
            if(nodeX.nextDay.data.getterDay()==item.data.getterDay())
                break;
            nodeX = nodeX.nextDay;
        }
        return nodeX;
    }

    private void removeFromDay(Node element,int index) throws Exception {
        if(size==1){
            Node temp=head;
            if(head!=null)
                head=head.next;
            if(temp!=null) {
                size--;
                daySize--;
            }
        }
        else if(index==0 && element.data.getterDay()!=element.next.data.getterDay()){
            Node temp=getDayNode(element.data.getterDay());
            if(element!=null)
                element=element.next;
            if(temp!=null){
                size--;
            }
        }
    }

    private Node getDayIndex(Node start,int index) throws Exception {
        Node nodeX=start;
        if(nodeX==null){
            throw new Exception("My handle null exception");
        }
        Node cond=nodeX.nextDay;
        int count=0;
        if(index<0 || index>=size)
            throw new Exception("Index bound error!");
        while(count<index) {
            if(nodeX==cond)
                break;
            nodeX = nodeX.next;
            count++;
        }
        if(cond==nodeX)
            throw new Exception(" Specific day list index bound error!");
        return nodeX;
    }

    private Node getDayNode(int day){
        Node nodeX=head;
        while (nodeX != null) {
            if(nodeX.data.getterDay()==day)
                break;
            nodeX = nodeX.nextDay;
        }
        return nodeX;
    }

    /**
     * addDayNode method is used to take forward list in terms of day.
     * @param day It is used to access first node in parameter day.
     * @return  First node(experiment) in a specific day.
     */
    private Node addDayNode(int day){
        Node nodeX=head;
        if(nodeX.nextDay==null){
            nodeX=getDayLastNode(nodeX);
            if(nodeX.data.getterDay()!=day)
                daySize++;
            return head;
        }
        else {
            while (nodeX.nextDay != null) {
                if(nodeX.data.getterDay()==day)
                    break;
                nodeX = nodeX.nextDay;
            }
            if (nodeX.data.getterDay() != day)
                daySize++;
            return nodeX;
        }
    }

    /**
     *  getDayLastNode method is used to take forward list in a given day.
     * @param start start first node(experiment) in day
     * @return  last node(experiment) in day;
     */
    private Node getDayLastNode(Node start){
        Node nodeX=start;
        while(nodeX!=null) {
            if(nodeX.next==start.nextDay)
                break;
            nodeX = nodeX.next;
        }
        return nodeX;
    }

    public void listAll()
    {
        System.out.println("List experiment view:");
        Node last = head;
        while( last != null) {
            System.out.println(last.data.toString());
            last = last.next;
        }
        System.out.println("List day view:");
        last = head;
        while( last != null) {
            System.out.println(last.data.toString());
            last = last.nextDay;
        }
    }

}

