public interface Iterable {
    public Iterator iterator();
    public Iterator iterator(int i);
}

