import static org.junit.Assert.*;

public class ExperimentListTest {

    @org.junit.Test
    public void orderDay() throws Exception {
        ExperimentList last=new ExperimentList();
        ExperimentList first=new ExperimentList(last.getterHead());
        last.addExp(new Experiment("Work4","05:32:07",true,1,4));
        last.addExp(new Experiment("Work2","09:52:17",true,1,3));
        last.addExp(new Experiment("Work2","09:52:17",true,1,2));
        last.addExp(new Experiment("Work2","09:52:17",false,1,0));
        last.addExp(new Experiment("Work3","13:32:26",true,4,4));
        last.orderDay(1);
        // According to example, Output will be change... NotEquals
        assertNotEquals(first.toString(),last.toString());
    }

    @org.junit.Test
    public void listExp() throws Exception {
        ExperimentList first=new ExperimentList();
        first.addExp(new Experiment("Work4","05:32:07",true,1,4));
        first.addExp(new Experiment("Work1","09:52:17",true,1,3));
        first.addExp(new Experiment("Work2","09:52:17",true,1,2));
        first.addExp(new Experiment("Work5","09:52:17",false,1,0));
        first.addExp(new Experiment("Work3","13:32:26",true,1,4));
        ExperimentList last=first.listExp(1);
        // One of them is not completed thus assertNotEquals...
        assertNotEquals(last.toString(),first.toString());
    }

    @org.junit.Test
    public void removeDay() throws Exception {
        ExperimentList first=new ExperimentList();
        first.addExp(new Experiment("Work1","09:52:17",true,2,3));
        first.addExp(new Experiment("Work2","09:52:17",true,2,2));
        ExperimentList second=new ExperimentList(first.getterHead());
        first.addExp(new Experiment("Work4","05:32:07",true,1,4));
        first.addExp(new Experiment("Work5","09:52:17",false,1,0));
        first.addExp(new Experiment("Work3","13:32:26",true,1,4));
        first.removeDay(1);
        // They will be equal since The second day list is permanent...
        assertEquals(first.toString(),second.toString());
    }

    @org.junit.Test
    public void removeExp() throws Exception {
        ExperimentList first=new ExperimentList();
        first.addExp(new Experiment("Work1","09:52:17",true,2,3));
        first.addExp(new Experiment("Work2","09:52:17",true,2,2));
        first.addExp(new Experiment("Work4","05:32:07",true,1,4));
        first.addExp(new Experiment("Work5","09:52:17",false,1,0));
        ExperimentList second=new ExperimentList(first.getterHead());
        first.addExp(new Experiment("Work3","13:32:26",true,1,4));
        first.removeExp(1,2);
        // day1 index=2 deleting... Work3 in day1.
        assertEquals(first.toString(),second.toString());
    }

    @org.junit.Test
    public void setExp() throws Exception {
        ExperimentList first=new ExperimentList();
        first.addExp(new Experiment("Work1","",true,2,4));
        first.addExp(new Experiment("Work2","",true,2,4));
        first.addExp(new Experiment("Work4","",true,1,4));
        first.addExp(new Experiment("Work5","",true,1,4));
        ExperimentList last=new ExperimentList(first.getterHead());
        ExperimentList same=new ExperimentList(first.getterHead());
        last.setExp(1,0,new Experiment("Work33","",true,1,4));
        same.setExp(1,0,new Experiment("Work4","",true,1,4));
        // ExperimentList's toString method only have setup and day dat fields, not others...
        // Since only they(setup and data) are distinctive features for these methods...
        assertNotEquals(first.toString(),last.toString());
        assertEquals(first.toString(),same.toString());
    }

    @org.junit.Test
    public void getExp() throws Exception {
        ExperimentList first=new ExperimentList();
        first.addExp(new Experiment("Work1","",true,2,4));
        first.addExp(new Experiment("Work2","",true,2,4));
        first.addExp(new Experiment("Work4","",true,1,4));
        first.addExp(new Experiment("Work5","",true,1,4));
        assertEquals(first.getExp(1,1).toString(),new Experiment("Work5","",true,1,4).toString());
        assertEquals(first.getExp(2,0).toString(),new Experiment("Work1","",true,2,4).toString());
    }

    @org.junit.Test
    public void addExp() throws Exception {
        ExperimentList first=new ExperimentList();
        ExperimentList second=new ExperimentList();
        // to add first list variable
        first.addExp(new Experiment("Work1","",true,2,4));
        first.addExp(new Experiment("Work2","",true,2,4));
        first.addExp(new Experiment("Work4","",true,1,4));
        first.addExp(new Experiment("Work5","",true,1,4));
        // to add second list variable
        second.addExp(new Experiment("Work1","",true,2,4));
        second.addExp(new Experiment("Work2","",true,2,4));
        second.addExp(new Experiment("Work4","",true,1,4));
        second.addExp(new Experiment("Work5","",true,1,4));
        assertEquals(first.toString(),second.toString());
    }

    @org.junit.Test
    public void iterator() throws Exception {
        ExperimentList first=new ExperimentList();
        ExperimentList last=new ExperimentList();
        ExperimentList same=new ExperimentList();
        last.addExp(new Experiment("Work1","",true,2,4));
        same.addExp(new Experiment("Work1","",true,2,4));
        Iterator iter1=first.iterator();
        Iterator iter2=last.iterator();
        Iterator iter3=same.iterator();
        /* hasNext() method comparing...    */
        assertNotEquals(iter1.hasNext(),iter2.hasNext());
        assertEquals(iter2.hasNext(),iter3.hasNext());
        /*
            iter2 and iter3 only one and same element. Thus It must use iter.next() one time. Otherwise NoSuchElementException
            This error will be not cause from my project
        */
        assertEquals(iter2.next().toString(), iter3.next().toString());
    }

    @org.junit.Test
    public void orderExperiments() throws Exception {
        ExperimentList list=new ExperimentList();
        list.addExp(new Experiment("Work4","05:32:07",true,1,2));
        list.addExp(new Experiment("Work2","09:52:17",false,1,0));
        list.addExp(new Experiment("Work3","13:32:26",true,4,4));
        ExperimentList result=list.orderExperiments();
        // I compared with accuracy data. It is important data for the method....
        assertNotEquals(result.toString(),new Experiment("Work2","09:52:17",false,1,0).toString());
    }


}